-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 20, 2015 at 04:55 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dbsoc`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminlogin`
--

CREATE TABLE IF NOT EXISTS `adminlogin` (
  `login_id` int(11) NOT NULL AUTO_INCREMENT,
  `uname` varchar(20) NOT NULL,
  `pwd` varchar(20) NOT NULL,
  PRIMARY KEY (`login_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `adminlogin`
--

INSERT INTO `adminlogin` (`login_id`, `uname`, `pwd`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `advertisement`
--

CREATE TABLE IF NOT EXISTS `advertisement` (
  `adv_id` int(11) NOT NULL AUTO_INCREMENT,
  `adv_name` varchar(20) NOT NULL,
  `adv_mob` bigint(15) NOT NULL,
  `adv_email` varchar(30) NOT NULL,
  `adv_title` varchar(30) NOT NULL,
  `adv_img` varchar(20) NOT NULL,
  `adv_desc` longtext NOT NULL,
  PRIMARY KEY (`adv_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `advertisement`
--

INSERT INTO `advertisement` (`adv_id`, `adv_name`, `adv_mob`, `adv_email`, `adv_title`, `adv_img`, `adv_desc`) VALUES
(1, 'Patel Pooja', 9898025805, 'patelpooja2713@gmail.com', 'Flat for rent', 'download (3).jpg', '8th floor,3bhk,full facilities with latest aminities'),
(2, 'Rakesh Sharma', 8794510632, 'rakesh@gmail.com', 'Flat for sale', '93980_0.jpg', '2nd floor,with balcony at roadside and latest aminities'),
(3, 'Akshay Patel', 7874310740, 'akshaypatel@yahoo.com', 'Flat for rent', 'gallery.jpg', '1st floor,semi furnished house'),
(4, 'Ankur Shah', 9874563012, 'ankur@yahoo.com', 'Flat for sale', 'tumblr_lia.jpg', '9th floor,garden side with latest aminities');

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE IF NOT EXISTS `city` (
  `city_id` int(11) NOT NULL AUTO_INCREMENT,
  `state_id` int(11) NOT NULL,
  `city_name` varchar(15) NOT NULL,
  PRIMARY KEY (`city_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`city_id`, `state_id`, `city_name`) VALUES
(1, 1, 'Ahmedabad'),
(2, 2, 'Mumbai'),
(3, 5, 'Amritsar'),
(4, 4, 'Panchmadhi'),
(5, 3, 'Bihar'),
(6, 1, 'Mehsana'),
(7, 1, 'Gandhinagar'),
(9, 1, 'Surat'),
(10, 1, 'Mumbai'),
(11, 2, 'Matheran');

-- --------------------------------------------------------

--
-- Table structure for table `complain`
--

CREATE TABLE IF NOT EXISTS `complain` (
  `comp_id` int(11) NOT NULL AUTO_INCREMENT,
  `u_id` int(11) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `block` varchar(5) NOT NULL,
  `date` date NOT NULL,
  `comp_title` varchar(30) NOT NULL,
  `comp_desc` longtext NOT NULL,
  `status` int(5) NOT NULL COMMENT '0=common,1=personal',
  PRIMARY KEY (`comp_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `complain`
--

INSERT INTO `complain` (`comp_id`, `u_id`, `uname`, `block`, `date`, `comp_title`, `comp_desc`, `status`) VALUES
(1, 1, 'Alisha Zaveri ', '', '2015-04-06', 'Parking Problem', 'Due to increase of vehicles their is lot of problem for parking', 0),
(2, 1, 'Alisha Zaveri ', 'A', '2015-04-03', 'Lift not working', 'lift is not working since 2 days', 1),
(3, 2, 'Patel Pooja', 'B', '2015-04-08', 'Pipeline leakage', 'Water line is leaking since 2 days ', 1),
(4, 3, 'Rakesh Sharma', '', '2015-03-30', 'Garbage not collected', 'garbage is not collected from ground', 0),
(5, 5, 'Akash P. Shah', 'A', '2015-04-06', 'Parking light not working', 'parking light not working since 3 days', 1),
(6, 6, 'Akshay Patel', '', '2015-04-08', 'Water Motor not working', 'Water motor not working since 3 days', 0);

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE IF NOT EXISTS `event` (
  `event_id` int(11) NOT NULL AUTO_INCREMENT,
  `event_name` varchar(20) NOT NULL,
  `event_date` date NOT NULL,
  `event_time` varchar(10) NOT NULL,
  `event_place` varchar(20) NOT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`event_id`, `event_name`, `event_date`, `event_time`, `event_place`) VALUES
(1, 'Navratri', '2015-03-04', '20:00', 'Play Ground'),
(2, 'Republic Day', '2015-01-26', '08:00', 'Play Ground'),
(3, 'Diwali', '2014-11-20', '19:00', 'Play Ground'),
(4, 'Uttrayan competition', '2015-01-14', '09:00', 'Play Ground'),
(5, 'Republic Day', '2014-08-15', '14:00', 'Play Ground');

-- --------------------------------------------------------

--
-- Table structure for table `expense`
--

CREATE TABLE IF NOT EXISTS `expense` (
  `exp_id` int(11) NOT NULL AUTO_INCREMENT,
  `exp_year` int(4) NOT NULL,
  `exp_sub` varchar(30) NOT NULL,
  `exp_amt` int(10) NOT NULL,
  PRIMARY KEY (`exp_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `expense`
--

INSERT INTO `expense` (`exp_id`, `exp_year`, `exp_sub`, `exp_amt`) VALUES
(1, 2011, 'road construction in flats', 75000),
(2, 2009, 'society renovation', 200000),
(3, 2012, 'blood donation camp', 15000),
(4, 2012, 'navratri mohatsav', 35000),
(5, 2013, 'janmashtami mohatsav', 20000),
(7, 2014, 'Diwali celebration', 15000);

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE IF NOT EXISTS `faq` (
  `faq_id` int(11) NOT NULL AUTO_INCREMENT,
  `faq_que` varchar(50) NOT NULL,
  `faq_ans` longtext NOT NULL,
  PRIMARY KEY (`faq_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `faq`
--

INSERT INTO `faq` (`faq_id`, `faq_que`, `faq_ans`) VALUES
(1, 'How does e-society works?', 'All the process works online here. Manual system is converted to online.'),
(2, 'Does maintenance payment is done online? ', 'Yes, members can pay the maintenance online by visiting the site.'),
(3, 'What can the members do?', 'The members can upload the advertisement, post the complain, give the feedback.'),
(4, 'Can visitors view the system?', 'No. They can only give the feedback and read the post.'),
(5, 'Does e-society organize functions?', 'Yes. Functions like navratri, holi, janmashtami, etc are held here.'),
(7, 'Is this helpful?', 'Yes, its very helpful for online purpose.');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `fback_id` int(11) NOT NULL AUTO_INCREMENT,
  `fback_name` varchar(20) NOT NULL,
  `fback_email` varchar(30) NOT NULL,
  `fback_msg` longtext NOT NULL,
  `fback_status` int(11) NOT NULL,
  PRIMARY KEY (`fback_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`fback_id`, `fback_name`, `fback_email`, `fback_msg`, `fback_status`) VALUES
(1, 'Rakesh Sharma', 'rakeshsharma@gmail.com', 'Thank you for solving the leakage problem', 1),
(2, 'Deepak Shah', 'deepakshah@ymail.com', 'Thank you for looking at the problem so soon', 0),
(3, 'Rohit Mehta', 'rohitmehta27@gmail.com', 'The navratri function was very good. Enjoyed a lot', 1),
(4, 'Mehul Raval', 'mehul@ymail.com', 'It good for busy men', 0),
(5, 'Khusabu Varama', 'khusabu@gmail.com', 'It Good', 1);

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE IF NOT EXISTS `gallery` (
  `gallery_id` int(11) NOT NULL AUTO_INCREMENT,
  `gallery_name` varchar(30) NOT NULL,
  `image` varchar(70) NOT NULL,
  PRIMARY KEY (`gallery_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`gallery_id`, `gallery_name`, `image`) VALUES
(1, 'navarati', 'download (4).jpg'),
(2, 'holi', 'download (6).jpg'),
(10, 'Uttarayan', 'images (15).jpg'),
(6, 'Holi', '322511535953.jpg'),
(7, 'janamastami', 'janmastmi.png'),
(14, 'Holi', 'download (6).jpg');

-- --------------------------------------------------------

--
-- Table structure for table `income`
--

CREATE TABLE IF NOT EXISTS `income` (
  `income_id` int(11) NOT NULL AUTO_INCREMENT,
  `income_amt` int(10) NOT NULL,
  `income_year` int(4) NOT NULL,
  `income_title` varchar(30) NOT NULL,
  `income_desc` longtext NOT NULL,
  PRIMARY KEY (`income_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `income`
--

INSERT INTO `income` (`income_id`, `income_amt`, `income_year`, `income_title`, `income_desc`) VALUES
(1, 150000, 2011, 'maintenance', 'total maintenance amount of 2011'),
(2, 25000, 2012, 'navratri fund', 'collected amount for navratri mohatsav'),
(3, 10000, 2012, 'blood donation camp', 'collected fund for blood donation camp '),
(4, 25000, 2013, 'janmashtami', 'collected fund for janmashtami mohatsav'),
(5, 200000, 2009, 'society renovation', 'amount collected for society renovation'),
(6, 10000, 2011, 'Polio fund', 'amount collected for polio camp');

-- --------------------------------------------------------

--
-- Table structure for table `maintenance`
--

CREATE TABLE IF NOT EXISTS `maintenance` (
  `main_id` int(11) NOT NULL AUTO_INCREMENT,
  `u_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `fix_amt` int(5) NOT NULL,
  `months` int(5) NOT NULL,
  `tot_amt` int(10) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`main_id`),
  UNIQUE KEY `order_id` (`order_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `maintenance`
--

INSERT INTO `maintenance` (`main_id`, `u_id`, `order_id`, `uname`, `fix_amt`, `months`, `tot_amt`, `date`) VALUES
(1, 1, 28679, 'Alisha Zaveri ', 500, 2, 1000, '2015-04-01'),
(2, 2, 11264, 'Patel Pooja', 500, 3, 1500, '2015-04-08'),
(3, 3, 24518, 'Rakesh Sharma', 500, 4, 2000, '2015-04-02'),
(4, 1, 17263, 'Alisha Zaveri ', 500, 3, 1500, '2015-05-01'),
(5, 5, 48004, 'Akash P. Shah', 500, 3, 1500, '2015-04-07'),
(6, 6, 19898, 'Akshay Patel', 500, 3, 1500, '2015-04-07'),
(7, 6, 21597, 'Akshay Patel', 500, 4, 2000, '2015-06-23'),
(8, 2, 20565, 'Patel Pooja', 500, 3, 1500, '2015-04-18'),
(9, 4, 37424, 'Ankur Shah', 500, 4, 2000, '2015-04-20'),
(10, 2, 18199, 'Patel Pooja', 500, 5, 2500, '2015-04-19');

-- --------------------------------------------------------

--
-- Table structure for table `meeting`
--

CREATE TABLE IF NOT EXISTS `meeting` (
  `meet_id` int(11) NOT NULL AUTO_INCREMENT,
  `meet_title` varchar(30) NOT NULL,
  `meet_invit` varchar(20) NOT NULL,
  `meet_place` varchar(20) NOT NULL,
  `meet_time` varchar(10) NOT NULL,
  `meet_date` date NOT NULL,
  PRIMARY KEY (`meet_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `meeting`
--

INSERT INTO `meeting` (`meet_id`, `meet_title`, `meet_invit`, `meet_place`, `meet_time`, `meet_date`) VALUES
(1, 'General meeting', 'All Members', 'Play Ground', '20:00', '2015-04-26'),
(2, 'Games Event meeting', 'All Members', 'Play Ground', '20:30', '2015-05-03'),
(3, 'Society Related meeting', 'Committee Members', 'Club House', '20:00', '2015-05-07'),
(4, 'Picnic Related meeting', 'All Members', 'Play Ground', '19:30', '2015-05-13');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `news_id` int(11) NOT NULL AUTO_INCREMENT,
  `news_title` varchar(30) NOT NULL,
  `news_date` date NOT NULL,
  `news_desc` longtext NOT NULL,
  PRIMARY KEY (`news_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`news_id`, `news_title`, `news_date`, `news_desc`) VALUES
(1, 'blood donation camp', '2015-05-12', 'blood donation camp on 12-13 May on paly ground 9:00AM to 5:00PM'),
(2, 'Polio Camp', '2015-05-16', 'Polio camp in Club House 10:00AM'),
(3, 'Halth Checkup camp', '2015-06-03', 'Per Person Fee 1000 and check all body 10:00AM to 4:30PM'),
(4, 'Eyes Checkup', '2015-05-14', 'Uma school start 10:00AM to 5:00PM');

-- --------------------------------------------------------

--
-- Table structure for table `occupation`
--

CREATE TABLE IF NOT EXISTS `occupation` (
  `occ_id` int(11) NOT NULL AUTO_INCREMENT,
  `occ_name` varchar(20) NOT NULL,
  PRIMARY KEY (`occ_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `occupation`
--


-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE IF NOT EXISTS `payment` (
  `pay_id` int(11) NOT NULL AUTO_INCREMENT,
  `u_id` int(11) NOT NULL,
  `main_id` int(11) NOT NULL,
  `acc_no` int(15) NOT NULL,
  `tot_amt` int(5) NOT NULL,
  `months` int(5) NOT NULL,
  `soc_acct` int(15) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`pay_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`pay_id`, `u_id`, `main_id`, `acc_no`, `tot_amt`, `months`, `soc_acct`, `date`) VALUES
(1, 1, 0, 789456, 3500, 7, 123456, '2015-03-31'),
(2, 1, 0, 789456, 2500, 5, 123456, '2015-04-08'),
(3, 1, 5, 0, 2000, 4, 0, '2015-04-08'),
(4, 9, 6, 2496, 1000, 2, 123456, '2015-04-15'),
(5, 9, 7, 457896, 1000, 2, 145263, '2015-04-01'),
(6, 1, 8, 12345, 1000, 2, 78945, '2015-04-07');

-- --------------------------------------------------------

--
-- Table structure for table `place_permission`
--

CREATE TABLE IF NOT EXISTS `place_permission` (
  `plc_id` int(11) NOT NULL AUTO_INCREMENT,
  `u_id` int(11) NOT NULL,
  `plc_name` varchar(20) NOT NULL,
  `plc_event` varchar(20) NOT NULL,
  `plc_date` date NOT NULL,
  `plc_time` varchar(10) NOT NULL,
  `plc_place` varchar(20) NOT NULL,
  PRIMARY KEY (`plc_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `place_permission`
--

INSERT INTO `place_permission` (`plc_id`, `u_id`, `plc_name`, `plc_event`, `plc_date`, `plc_time`, `plc_place`) VALUES
(1, 2, 'Patel Pooja', 'Birthday Party', '2015-04-23', '19:30', 'Club House'),
(2, 1, 'Alisha Zaveri ', 'Havan', '2015-04-29', '08:00', 'Club House'),
(3, 6, 'Akshay Patel', 'Party', '2015-04-27', '18:30', 'Play Ground'),
(4, 5, 'Akash P. Shah', 'Dinner function', '2015-04-27', '18:00', 'Play Ground'),
(5, 5, 'Akash P. Shah', 'Birthaday Party', '2015-05-07', '19:00', 'Club House'),
(6, 1, 'Alisha Zaveri ', 'party', '2015-05-13', '19:00', 'Play Ground');

-- --------------------------------------------------------

--
-- Table structure for table `place_response`
--

CREATE TABLE IF NOT EXISTS `place_response` (
  `res_id` int(11) NOT NULL AUTO_INCREMENT,
  `plc_id` int(11) NOT NULL,
  `u_id` int(11) NOT NULL,
  `msg` varchar(100) NOT NULL,
  PRIMARY KEY (`res_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `place_response`
--

INSERT INTO `place_response` (`res_id`, `plc_id`, `u_id`, `msg`) VALUES
(1, 1, 2, 'yes use'),
(2, 2, 1, 'yes use it'),
(3, 3, 6, 'yes you can use'),
(4, 4, 5, 'no place not free'),
(5, 5, 5, 'yes use it'),
(6, 6, 1, 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
  `pro_id` int(11) NOT NULL AUTO_INCREMENT,
  `u_id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `address` longtext NOT NULL,
  `block` varchar(5) NOT NULL,
  `nationality` varchar(20) NOT NULL,
  `religion` varchar(20) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(10) NOT NULL,
  `edu_qualification` varchar(30) NOT NULL,
  `occupation` varchar(30) NOT NULL,
  `mob_no` bigint(15) NOT NULL,
  `email` varchar(30) NOT NULL,
  `hobbies` longtext NOT NULL,
  `image` varchar(20) NOT NULL,
  `flat_type` varchar(20) NOT NULL,
  `total_memb` int(10) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `pwd` varchar(50) NOT NULL,
  `s_id` int(11) NOT NULL,
  `s_ans` longtext NOT NULL,
  `status` int(11) DEFAULT '1',
  PRIMARY KEY (`pro_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`pro_id`, `u_id`, `name`, `address`, `block`, `nationality`, `religion`, `dob`, `gender`, `edu_qualification`, `occupation`, `mob_no`, `email`, `hobbies`, `image`, `flat_type`, `total_memb`, `uname`, `pwd`, `s_id`, `s_ans`, `status`) VALUES
(1, 1, 'Alisha Zaveri ', 'vasna ', 'A', 'Indian', 'Hindu', '2015-03-30', 'female', 'B.Tech', 'student', 7874160530, 'alishazaveri91@gmail.com', 'Reading,Singing,Dancing', '011.jpg', 'Own', 3, 'alisha', '00960bc77851445ed41756ab65f4cdb0', 1, 'alu', 0),
(2, 2, 'Patel Pooja', 'Gandhinagar ', 'B', 'Australian', 'Christian', '1994-05-21', 'female', 'B.Tech', 'student', 9898023906, 'patelpooja2713@gmail.com', 'Singing,Dancing', '05.jpg', 'Rent', 4, 'pooja', '72e0ebdc6f4cd073e9d6a943feb2a37d', 1, 'gopi', 0),
(3, 3, 'Rakesh Sharma', 'Paldi ', 'C', 'Chinese', 'Punjabi', '2015-04-01', 'male', 'B.Com', 'Service', 8746951032, 'rakeshsharma@gmail.com', 'Reading,Others', '02.jpg', 'Rent', 5, 'rakesh', '4cd983fce0ee8588ffbed6353e0b030a', 2, 'Ankur', 0),
(4, 4, 'Ankur Shah', 'Vasana', 'B', 'Australian', 'Muslim', '1970-07-23', 'male', 'BHMS', 'Service', 7402347280, 'ankur@yahoo.com', 'Reading,Writing', '03.jpg', 'Rent', 4, 'ankur', 'e104c000ba2bf871deada58d00203f70', 2, 'DPS', 0),
(5, 5, 'Akash P. Shah', 'Baroda', 'A', 'Indian', 'Jain', '0000-00-00', 'male', 'B.Com', 'Bussiness', 9874203651, 'akashshah@gmail.com', 'Reading', '6.jpg', 'Rent', 3, 'akash', 'cb7c5f69ff356ecca55b7d08df877991', 4, 'salman', 0),
(6, 6, 'Akshay Patel', 'Naroda', 'C', 'Japanese', 'Punjabi', '2015-03-29', 'male', 'B.Com', 'Service', 8745963012, 'akshaypatel@yahoo.com', 'Reading,Dancing', '07.jpg', 'Rent', 4, 'akshay', 'c48f745b8d9bd91268e9bd1314ae5212', 1, 'akki', 0);

-- --------------------------------------------------------

--
-- Table structure for table `religions`
--

CREATE TABLE IF NOT EXISTS `religions` (
  `rel_id` int(11) NOT NULL AUTO_INCREMENT,
  `rel_name` varchar(20) NOT NULL,
  PRIMARY KEY (`rel_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `religions`
--

INSERT INTO `religions` (`rel_id`, `rel_name`) VALUES
(1, 'Hindu'),
(2, 'Muslim'),
(3, 'Jain'),
(4, 'Christian'),
(5, 'Sikh'),
(6, 'Sindhi');

-- --------------------------------------------------------

--
-- Table structure for table `security_question`
--

CREATE TABLE IF NOT EXISTS `security_question` (
  `s_id` int(11) NOT NULL AUTO_INCREMENT,
  `s_que` varchar(30) NOT NULL,
  PRIMARY KEY (`s_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `security_question`
--

INSERT INTO `security_question` (`s_id`, `s_que`) VALUES
(1, 'What is your nick name?'),
(2, 'What is your school name?'),
(3, 'What is your hobby?'),
(4, 'Who is your favourite hero?');

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE IF NOT EXISTS `state` (
  `state_id` int(11) NOT NULL AUTO_INCREMENT,
  `state_name` varchar(15) NOT NULL,
  PRIMARY KEY (`state_id`),
  KEY `state_id` (`state_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`state_id`, `state_name`) VALUES
(1, 'Gujarat'),
(2, 'Maharastra'),
(3, 'UP'),
(4, 'MP'),
(5, 'Punjab'),
(7, 'Karnatak');

-- --------------------------------------------------------

--
-- Table structure for table `userlogin`
--

CREATE TABLE IF NOT EXISTS `userlogin` (
  `u_id` int(11) NOT NULL AUTO_INCREMENT,
  `uname` varchar(20) NOT NULL,
  `pwd` varchar(50) NOT NULL,
  PRIMARY KEY (`u_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `userlogin`
--

INSERT INTO `userlogin` (`u_id`, `uname`, `pwd`) VALUES
(1, 'rakesh', 'd905f67a789b9cf5969dd023dc20768c'),
(2, 'rakeshsharma', 'rakesh002'),
(3, 'rohit', 'rohit003'),
(4, 'deepak', 'deepak004'),
(5, 'jinesh', 'jinesh005');

-- --------------------------------------------------------

--
-- Table structure for table `user_registration`
--

CREATE TABLE IF NOT EXISTS `user_registration` (
  `reg_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `address` varchar(70) NOT NULL,
  `state` varchar(15) NOT NULL,
  `city` varchar(15) NOT NULL,
  `nationality` varchar(10) NOT NULL,
  `religion` varchar(10) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(10) NOT NULL,
  `mob_no` bigint(15) NOT NULL,
  `email_id` varchar(30) NOT NULL,
  `uname` varchar(20) NOT NULL,
  `pwd` varchar(20) NOT NULL,
  `confirm_pwd` varchar(20) NOT NULL,
  `s_que` varchar(30) NOT NULL,
  `s_ans` varchar(30) NOT NULL,
  PRIMARY KEY (`reg_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `user_registration`
--

INSERT INTO `user_registration` (`reg_id`, `name`, `address`, `state`, `city`, `nationality`, `religion`, `dob`, `gender`, `mob_no`, `email_id`, `uname`, `pwd`, `confirm_pwd`, `s_que`, `s_ans`) VALUES
(1, 'Rakesh Mehta', 'A-4, Royal Plaza, bh. drive in road', '1', '1', 'Indian', 'Hindu', '1985-07-18', 'male', 7896541032, 'rakeshmehta65@ymail.com', 'rakesh', 'rakesh001', 'rakesh001', 'What is your nick name?', 'rinku'),
(2, 'Rakesh Sharma', 'B-4, Royal Plaza, bh. drive in road', '1', '1', 'Indian', 'Punjabi', '1983-08-04', 'male', 7458963012, 'rakeshsharma@gmail.com', 'rakeshsharma', 'rakesh002', 'rakesh002', 'What is your nick name?', 'chintu'),
(3, 'Rohit Mehta', 'C-12, Royal Plaza, bh. drive in road', '1', '1', 'Indian', 'Hindu', '1982-02-14', 'male', 7458963012, 'rohitmehta27@gmail.com', 'rohit', 'rohit003', 'rohit003', 'What is your hobby?', 'Reading'),
(4, 'Deepak Shah', 'A-8, Royal Plaza, bh. drive in road', '1', '9', 'Indian', 'Jain', '1987-07-07', 'male', 8745963012, 'deepakshah@ymail.com', 'deepak', 'deepak004', 'deepak004', 'What is your nick name?', 'pintu'),
(5, 'Jinesh Soni', 'C-6, Royal Plaza,bh. drive in road', '1', '1', 'Indian', 'Hindu', '1979-11-29', 'male', 8746951032, 'sonijinesh65@ymail.com', 'jinesh', 'jinesh005', 'jinesh005', 'What is your nick name?', 'jinu');
